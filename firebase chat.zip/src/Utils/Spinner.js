import React from 'react'

import {  MoonLoader } from "react-spinners";
export default function Spinner() {
  return (
    <div>
    <MoonLoader color="#1434A4" />
  </div>
  )
}




