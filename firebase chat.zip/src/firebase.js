export default firebaseInit = () =>{
    const firebaseConfig = {
        apiKey: "AIzaSyAXab0x7u_R8K2YpCC-SepABQ004F715HY",
        authDomain: "chatappfirestore-378007.firebaseapp.com",
        projectId: "chatappfirestore-378007",
        storageBucket: "chatappfirestore-378007.appspot.com",
        messagingSenderId: "426641543242",
        appId: "1:426641543242:web:027226e7faa39a9a2f16b3",
        measurementId: "G-5DYGY4TNVH"
      };
}
